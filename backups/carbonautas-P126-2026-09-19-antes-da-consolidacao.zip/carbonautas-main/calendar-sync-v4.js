/* Carbonautas · Google Calendar Sync V4 · P37 · 2026-09-15
   Corrige importacoes historicas e trata eventos passados do Google como concluidos.
   Mantem somente o ano atual em diante no Carbonautas; nao apaga eventos manuais.
*/
(function(){
'use strict';
const VERSION='P37';
const YEARS_FORWARD=5;
const MAX_EVENTS=12000;
const BATCH_SIZE=200;
const END_MARK=/\n?\[\[CARBONAUTAS_FIM:(\d{4}-\d{2}-\d{2})\|([0-2]\d:[0-5]\d)?\]\]\s*$/;

function safeDocPart(v=''){return String(v||'').replace(/[^a-zA-Z0-9_-]/g,'_').slice(0,900)}
function importedPrefix(){return `g_${safeDocPart(String(authUser?.uid||'user').slice(0,40))}_`}
function importedDocId(id){return importedPrefix()+safeDocPart(id)}
function todayIso(){const d=new Date();return agIso(d)}
function day(iso,n){const d=new Date(`${iso}T12:00:00`);d.setDate(d.getDate()+n);return agIso(d)}
function cleanDesc(t=''){return String(t||'').replace(END_MARK,'').replace(/\n\nSincronizado a partir da agenda privada do Carbonautas\.?\s*$/i,'').trim()}
function endParts(ge,start){
  if(ge?.end?.date)return{data:day(ge.end.date,-1),hora:''};
  if(ge?.end?.dateTime){const p=localDatePartsFromGoogle(ge.end);if(p)return{data:p.data,hora:p.hora}}
  return{data:start.data,hora:start.hora||''};
}
function markedDesc(ge,start){
  const e=endParts(ge,start),base=cleanDesc(ge.description||'').slice(0,2920);
  return `${base}${base?'\n':''}[[CARBONAUTAS_FIM:${e.data}|${e.hora||''}]]`.slice(0,3000);
}
function windowRange(){
  const y=new Date().getFullYear();
  const min=new Date(y,0,1,0,0,0,0),max=new Date(y+YEARS_FORWARD,11,31,23,59,59,999);
  return{min,max,minIso:`${y}-01-01`,maxIso:`${y+YEARS_FORWARD}-12-31`};
}
function googleEventPast(ge){
  const now=Date.now();
  if(ge?.end?.dateTime){const t=Date.parse(ge.end.dateTime);return Number.isFinite(t)&&t<=now}
  if(ge?.end?.date)return ge.end.date<=todayIso();
  if(ge?.start?.dateTime){const t=Date.parse(ge.start.dateTime);return Number.isFinite(t)&&t<now}
  if(ge?.start?.date)return ge.start.date<todayIso();
  return false;
}
function localImportedPast(ev){
  const desc=String(ev?.descricao||''),m=desc.match(END_MARK),today=todayIso();
  const d=m?.[1]||ev?.data||'';
  const h=m?.[2]||'';
  if(!d)return false;
  if(d<today)return true;
  if(d>today)return false;
  if(!h)return false;
  const now=new Date(),cur=String(now.getHours()).padStart(2,'0')+':'+String(now.getMinutes()).padStart(2,'0');
  return h<=cur;
}
async function listGoogleEvents(){
  await ensureGoogleCalendarToken();
  const{min,max,minIso,maxIso}=windowRange();
  const items=[];let token='',pages=0,truncated=false;
  do{
    const q=new URLSearchParams({timeMin:min.toISOString(),timeMax:max.toISOString(),singleEvents:'true',showDeleted:'false',orderBy:'startTime',maxResults:'2500'});
    if(token)q.set('pageToken',token);
    const data=await googleApi('/calendars/primary/events?'+q.toString());
    pages++;
    for(const ge of(data.items||[])){
      if(ge?.status==='cancelled')continue;
      items.push(ge);
      if(items.length>=MAX_EVENTS){truncated=true;break}
    }
    if(truncated)break;
    token=data.nextPageToken||'';
  }while(token&&pages<100);
  return{items,minIso,maxIso,truncated};
}
async function commitDeletes(refs){
  const f=FB();
  for(let i=0;i<refs.length;i+=BATCH_SIZE){const b=f.writeBatch(window.db);refs.slice(i,i+BATCH_SIZE).forEach(r=>b.delete(r));await b.commit()}
}
async function commitUpdates(ops){
  const f=FB();
  for(let i=0;i<ops.length;i+=BATCH_SIZE){const b=f.writeBatch(window.db);for(const op of ops.slice(i,i+BATCH_SIZE))b.update(op.ref,op.data);await b.commit()}
}
async function autoRepairImported(){
  const{minIso,maxIso}=windowRange(),f=FB(),pref=importedPrefix(),del=[],upd=[];
  for(const ev of(state.privateSchedule||[])){
    if(!String(ev.id||'').startsWith(pref))continue;
    if(!ev.data||ev.data<minIso||ev.data>maxIso){
      del.push(f.doc(window.db,'rede_private_schedule',ev.id));
      continue;
    }
    if(!ev.feito&&localImportedPast(ev))upd.push({ref:f.doc(window.db,'rede_private_schedule',ev.id),data:{feito:true,updatedAt:f.serverTimestamp()}});
  }
  if(del.length)await commitDeletes(del);
  if(upd.length)await commitUpdates(upd);
  return{removed:del.length,completed:upd.length};
}
async function cleanupImported(items,minIso,maxIso){
  const f=FB(),ids=new Set(items.map(x=>x.id).filter(Boolean)),pref=importedPrefix(),refs=[];
  for(const ev of(state.privateSchedule||[])){
    if(!String(ev.id||'').startsWith(pref))continue;
    const outside=!ev.data||ev.data<minIso||ev.data>maxIso;
    const orphan=!ev.googleEventId||!ids.has(ev.googleEventId);
    if(outside||orphan)refs.push(f.doc(window.db,'rede_private_schedule',ev.id));
  }
  if(refs.length)await commitDeletes(refs);
  return refs.length;
}
function createPayload(ge,dt){
  return{titulo:String(ge.summary||'(Sem título)').slice(0,300),data:dt.data,hora:String(dt.hora||'').slice(0,5),descricao:markedDesc(ge,dt),feito:googleEventPast(ge),ownerUid:authUser.uid,ownerMemberId:myId,createdAt:FB().serverTimestamp(),updatedAt:FB().serverTimestamp()};
}
function updatePayload(ge,dt){
  return{titulo:String(ge.summary||'(Sem título)').slice(0,300),data:dt.data,hora:String(dt.hora||'').slice(0,5),descricao:markedDesc(ge,dt),feito:googleEventPast(ge),googleEventId:String(ge.id||''),googleHtmlLink:String(ge.htmlLink||''),googleSyncedAt:FB().serverTimestamp(),updatedAt:FB().serverTimestamp()};
}
async function writeOps(ops){
  const f=FB();
  for(let i=0;i<ops.length;i+=BATCH_SIZE){const b=f.writeBatch(window.db);for(const op of ops.slice(i,i+BATCH_SIZE)){if(op.kind==='create')b.set(op.ref,op.data);else b.update(op.ref,op.data)}await b.commit()}
}
async function pull(){
  const btn=document.querySelector('#pullGoogleBtn');
  if(!authUser?.uid||!myId)return toast('Sua conta precisa estar vinculada a um Carbonauta.');
  try{
    if(btn){btn.disabled=true;btn.textContent='↓ Lendo agenda…'}
    const{items,minIso,maxIso,truncated}=await listGoogleEvents();
    if(btn)btn.textContent='↓ Limpando importações antigas…';
    const removidos=await cleanupImported(items,minIso,maxIso);
    const ids=new Set(items.map(g=>g.id));
    const locals=(state.privateSchedule||[]).filter(x=>!(String(x.id||'').startsWith(importedPrefix())&&(!x.data||x.data<minIso||x.data>maxIso||!x.googleEventId||!ids.has(x.googleEventId))));
    const byGoogle=new Map(locals.filter(x=>x.googleEventId).map(x=>[x.googleEventId,x]));
    const f=FB(),first=[],meta=[];let novos=0,atualizados=0,ignorados=0;
    for(const ge of items){
      const dt=localDatePartsFromGoogle(ge.start);
      if(!dt||!ge.id||!/^\d{4}-\d{2}-\d{2}$/.test(dt.data||'')){ignorados++;continue}
      const local=byGoogle.get(ge.id)||null;
      if(local){first.push({kind:'update',ref:f.doc(window.db,'rede_private_schedule',local.id),data:updatePayload(ge,dt)});atualizados++}
      else{
        const ref=f.doc(window.db,'rede_private_schedule',importedDocId(ge.id));
        first.push({kind:'create',ref,data:createPayload(ge,dt)});
        meta.push({kind:'update',ref,data:{googleEventId:String(ge.id),googleHtmlLink:String(ge.htmlLink||''),googleSyncedAt:f.serverTimestamp(),updatedAt:f.serverTimestamp()}});
        novos++;
      }
    }
    if(btn)btn.textContent=`↓ Salvando ${novos+atualizados} eventos…`;
    await writeOps(first);if(meta.length)await writeOps(meta);
    toast(`Agenda corrigida: ${removidos} importações antigas removidas; ${novos} novas; ${atualizados} atualizadas. Período ${minIso.slice(0,4)}–${maxIso.slice(0,4)}${ignorados?` · ${ignorados} ignoradas`:''}${truncated?' · limite atingido':''}.`);
  }catch(e){console.error('P37 Google->Carbonautas',e);toast(e?.message||'Não consegui atualizar sua agenda.')}
  finally{if(btn){btn.disabled=false;btn.textContent='↓ Trazer agenda do Google'}}
}
function showYears(){
  try{
    const listBtn=document.querySelector('#agModes button[data-ag-mode="lista"]');if(!listBtn?.classList.contains('on'))return;
    document.querySelectorAll('.ag-item[data-ag-id]').forEach(el=>{
      const raw=el.getAttribute('data-ag-id')||'',i=raw.indexOf('|');if(i<0)return;
      const kind=raw.slice(0,i),id=raw.slice(i+1);let ev=null;
      if(kind==='privado')ev=(state.privateSchedule||[]).find(x=>x.id===id);
      if(!ev?.data)return;
      const y=ev.data.slice(0,4),t=el.querySelector('.ag-time');
      if(t&&!t.querySelector('.p37-year'))t.insertAdjacentHTML('beforeend',`<br><span class="p37-year" style="font-size:10px;opacity:.72">${y}</span>`);
    });
  }catch(e){}
}
function wire(){
  const b=document.querySelector('#pullGoogleBtn');
  if(b){b.textContent='↓ Trazer agenda do Google';b.title='Sincroniza do início do ano atual em diante e remove importações antigas do Google.';b.onclick=pull}
  showYears();
}
let repairAttempts=0;
async function scheduleAutoRepair(){
  try{
    repairAttempts++;
    if(typeof authUser==='undefined'||!authUser?.uid||typeof myId==='undefined'||!myId||typeof state==='undefined'||!Array.isArray(state.privateSchedule)||!state.privateSchedule.length){
      if(repairAttempts<30)setTimeout(scheduleAutoRepair,1000);
      return;
    }
    const key=`carbonautas_${VERSION}_repair_${authUser.uid}_${new Date().getFullYear()}`;
    if(localStorage.getItem(key)==='1')return;
    const r=await autoRepairImported();
    localStorage.setItem(key,'1');
    if(r.removed||r.completed)toast(`Agenda ajustada: ${r.removed} importações antigas removidas e ${r.completed} eventos passados arquivados.`);
  }catch(e){console.warn('P37 auto-repair',e);if(repairAttempts<30)setTimeout(scheduleAutoRepair,1500)}
}
new MutationObserver(()=>showYears()).observe(document.documentElement,{subtree:true,childList:true});
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{wire();setTimeout(scheduleAutoRepair,1200)},{once:true});
else{wire();setTimeout(scheduleAutoRepair,1200)}
window.pullGoogleToCarbonautasV4=pull;
console.info('Carbonautas Google Sync',VERSION,'carregado');
})();
