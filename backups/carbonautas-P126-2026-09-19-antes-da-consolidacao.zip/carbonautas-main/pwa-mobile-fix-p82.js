/* Carbonautas P84 · uma única verdade para PC + app + painel mobile */
(function(){
'use strict';
const BUILD='P84';
const ACK_PREFIX='carbonautas_p56_panel_done_';
const CLOUD_FIELD='panelStateV1';
let scheduled=false, checkinsExpanded=false, started=false, memberRef=null, unsub=null, writing=false, entries={};

const q=(s,r=document)=>r.querySelector(s);
const qa=(s,r=document)=>[...r.querySelectorAll(s)];
function F(){return window.fbFns}
function authUid(){return String(window.auth?.currentUser?.uid||'')}
function ackKey(){return ACK_PREFIX+(authUid()||'anon')}
function loadJSON(k){try{return JSON.parse(localStorage.getItem(k)||'{}')||{}}catch(_e){return{}}}
function saveJSON(k,v){try{localStorage.setItem(k,JSON.stringify(v||{}))}catch(_e){}}
function same(a,b){try{return JSON.stringify(a)===JSON.stringify(b)}catch(_e){return false}}
function now(){return Date.now()}
function cleanEntry(v={}){return {status:v.status==='open'?'open':'done',changedAt:Number(v.changedAt||v.doneAt||0)||0,meta:v.meta&&typeof v.meta==='object'?v.meta:{}}}
function trimEntries(v,max=160){return Object.fromEntries(Object.entries(v||{}).map(([k,x])=>[k,cleanEntry(x)]).sort((a,b)=>b[1].changedAt-a[1].changedAt).slice(0,max))}
function mergeEntries(a,b){const out={};for(const [k,v] of Object.entries(a||{}))out[k]=cleanEntry(v);for(const [k,v0] of Object.entries(b||{})){const v=cleanEntry(v0),old=out[k];if(!old||v.changedAt>=old.changedAt)out[k]=v}return trimEntries(out)}
function localAsEntries(){const a=loadJSON(ackKey()),out={};for(const [k,v] of Object.entries(a||{})){out[k]={status:'done',changedAt:Number(v?.doneAt||0)||now(),meta:v||{}}}return out}
function applyEntriesToLocal(all){const local={};for(const [k,v0] of Object.entries(all||{})){const v=cleanEntry(v0);if(v.status==='done')local[k]={...(v.meta||{}),key:k,doneAt:v.changedAt}}const old=loadJSON(ackKey());if(!same(old,local)){saveJSON(ackKey(),local);try{window.renderPainel?.();window.p77Refresh?.()}catch(_e){}}}

function canonicalize(){try{const u=new URL(location.href);if(u.searchParams.get('build')!==BUILD){u.searchParams.set('build',BUILD);u.searchParams.delete('pwa');history.replaceState(null,'',u.href)}}catch(_e){}}

function ensureStyle(){
  if(q('#p84Style'))return;
  const st=document.createElement('style');st.id='p84Style';st.textContent=`
  .tab[data-view="lab"],.app-nav-card[data-app-view="lab"]{display:none!important}
  #p78TodayCard{scroll-margin-top:16px}.p84-checkin-toggle{display:none}
  @media(max-width:760px){
    #viewPainel .dash-scroll{background:#f4f7f8!important}
    #viewPainel .dash-wrap{padding:12px 12px 44px!important;max-width:none!important;width:100%!important}
    #viewPainel .dash-hero{margin:0 0 12px!important;border-radius:22px!important;padding:20px 17px!important;gap:14px!important;box-shadow:0 8px 24px rgba(4,38,55,.08)!important;overflow:hidden!important}
    #viewPainel .dash-hero>div:first-child{min-width:0!important;width:100%!important}
    #viewPainel .dash-hero h2{font-size:29px!important;line-height:1.04!important;letter-spacing:-.035em!important;margin:0!important}
    #viewPainel .dash-hero p{font-size:13.5px!important;line-height:1.42!important;margin:9px 0 0!important;max-width:none!important}
    #viewPainel .dash-hero .spacer{display:none!important}
    #viewPainel .dash-hero-actions{width:100%!important;display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important}
    #viewPainel .dash-hero-actions .btn{width:100%!important;min-width:0!important;min-height:44px!important;padding:9px 7px!important;justify-content:center!important;border-radius:12px!important;font-size:12px!important;white-space:normal!important;text-align:center!important;line-height:1.15!important}
    #dashBackupBtn{grid-column:1/-1!important}
    #p78TodayCard{margin:0 0 12px!important;border-radius:18px!important;padding:14px!important;box-shadow:0 7px 20px rgba(10,70,76,.06)!important}
    #p78TodayCard .p78-title{font-size:17px!important}.p78-row{border-radius:12px!important;padding:9px!important}.p78-main b{font-size:12px!important}.p78-main span{font-size:10.5px!important}
    #dashKpis{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:10px!important;margin:0 0 12px!important;width:100%!important}
    #dashKpis .dash-kpi{min-width:0!important;width:100%!important;min-height:102px!important;border-radius:18px!important;padding:15px!important;display:flex!important;flex-direction:column!important;justify-content:center!important;box-shadow:none!important;background:#fff!important;overflow:hidden!important}
    #dashKpis .dash-kpi:nth-child(5){grid-column:1/-1!important;min-height:82px!important}
    #dashKpis .k-n{font-size:32px!important;line-height:1!important}.dash-kpi .k-l{font-size:11.5px!important;line-height:1.25!important;margin-top:7px!important}
    #viewPainel .dash-grid{display:block!important;width:100%!important}.dash-grid>aside{display:flex!important;gap:12px!important;margin-top:12px!important}
    #viewPainel .dash-card{border-radius:20px!important;padding:14px!important;margin:0!important;box-shadow:none!important;border:1px solid #dbe5e8!important;overflow:hidden!important}
    #viewPainel .dash-card-head{gap:8px!important;align-items:flex-start!important}.dash-card-head h3{font-size:21px!important;line-height:1.08!important}.dash-sub{font-size:11.5px!important;line-height:1.35!important}
    #dashAttention{gap:12px!important}.p56-panel-section{gap:9px!important}.p56-section-head{padding:3px 1px 5px!important;font-size:14px!important}
    .p56-task{grid-template-columns:1fr!important;gap:10px!important;border-radius:17px!important;padding:13px!important;min-width:0!important;width:100%!important;overflow:hidden!important;box-shadow:none!important}
    .p56-task-main,.p56-task-actions{min-width:0!important;width:100%!important}.p56-task-top{gap:6px!important}.p56-source{font-size:9px!important}.p56-date{font-size:10px!important}.p56-who{font-size:11.5px!important}.p56-what{font-size:16.5px!important;line-height:1.18!important;overflow-wrap:anywhere!important}.p56-detail{font-size:12.5px!important;line-height:1.4!important;overflow-wrap:anywhere!important;white-space:normal!important;max-width:100%!important}
    .p56-task-actions{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:7px!important;justify-content:stretch!important}.p56-task-actions .btn{width:100%!important;min-width:0!important;min-height:42px!important;height:auto!important;padding:8px 7px!important;justify-content:center!important;border-radius:11px!important;font-size:11.5px!important;white-space:normal!important;text-align:center!important}.p56-task-actions .btn:only-child{grid-column:1/-1!important}
    .p69-state,.p76-sent{max-width:100%!important;overflow-wrap:anywhere!important}.p70-smart-request,.p69-wait,.p72-checkin-remind{min-height:44px!important}
    .p56-done-box{border-radius:15px!important}.p56-done-row{grid-template-columns:26px minmax(0,1fr)!important}.p56-done-main span{white-space:normal!important;overflow:visible!important}.p56-undo{grid-column:2!important;text-align:left!important}
    .health-row{padding:9px 0!important}.health-person{min-width:0!important}.health-person b,.health-person span{overflow-wrap:anywhere!important}.health-score{font-size:10px!important}
    .p84-checkin-toggle{display:flex!important;width:100%!important;align-items:center!important;justify-content:space-between!important;gap:10px!important;border:1px solid #d8e5e8!important;background:#f7fbfc!important;color:#274650!important;border-radius:13px!important;padding:10px 11px!important;font-weight:850!important;font-size:11.5px!important;margin:2px 0 3px!important}
    .p84-checkin-hidden{display:none!important}
  }
  `;document.head.appendChild(st)
}
function relocateToday(){const hero=q('#viewPainel .dash-hero'),card=q('#p78TodayCard');if(hero&&card&&hero.nextElementSibling!==card)hero.insertAdjacentElement('afterend',card)}
function hideLab(){const x=q('.app-nav-card[data-app-view="lab"]');if(x)x.style.display='none'}
function organizeCheckins(){if(innerWidth>760)return;const root=q('#dashAttention');if(!root)return;const cards=qa('.p56-task',root).filter(c=>!c.classList.contains('p77-hidden-treated')&&/CHECK-IN/i.test(c.querySelector('.p56-source')?.textContent||''));let ctrl=q('#p84CheckinToggle');if(cards.length<=2){ctrl?.remove();cards.forEach(c=>c.classList.remove('p84-checkin-hidden'));return}if(!ctrl){ctrl=document.createElement('button');ctrl.type='button';ctrl.id='p84CheckinToggle';ctrl.className='p84-checkin-toggle';ctrl.onclick=()=>{checkinsExpanded=!checkinsExpanded;organizeCheckins()};cards[0].insertAdjacentElement('beforebegin',ctrl)}ctrl.innerHTML=`<span>👀 Check-ins pendentes</span><b>${cards.length} · ${checkinsExpanded?'recolher':'ver todos'}</b>`;cards.forEach((c,i)=>c.classList.toggle('p84-checkin-hidden',!checkinsExpanded&&i>=2))}
function polish(){canonicalize();ensureStyle();relocateToday();hideLab();organizeCheckins()}
function schedule(){if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;polish()})}

async function getProfile(){const f=F(),u=authUid();if(!f||!u)return null;try{const s=await f.getDoc(f.doc(window.db,'rede_users',u));return s.exists()?{...s.data(),uid:u}:null}catch(_e){return null}}
async function writeCloud(){if(writing||!memberRef||!F())return;writing=true;try{entries=trimEntries(entries);await F().updateDoc(memberRef,{[CLOUD_FIELD]:{entries},panelStateUpdatedAt:F().serverTimestamp()})}catch(e){console.warn('P84 painel cloud write',e)}finally{writing=false}}
function applyCloud(remote){const merged=mergeEntries(remote||{},localAsEntries());const changed=!same(entries,merged);entries=merged;applyEntriesToLocal(entries);if(changed)setTimeout(writeCloud,80)}
function noteDone(key,meta){entries=mergeEntries(entries,{[key]:{status:'done',changedAt:Number(meta?.doneAt||0)||now(),meta:meta||{}}});applyEntriesToLocal(entries);setTimeout(writeCloud,40)}
function noteOpen(key){entries=mergeEntries(entries,{[key]:{status:'open',changedAt:now(),meta:{key}}});applyEntriesToLocal(entries);setTimeout(writeCloud,40)}
function wrapActions(){if(window.p56AckItem&&!window.p56AckItem.__p84){const old=window.p56AckItem;const fn=function(key){const r=old.apply(this,arguments);setTimeout(()=>{const m=loadJSON(ackKey())[key]||{key,doneAt:now()};noteDone(key,m)},20);return r};fn.__p84=true;window.p56AckItem=fn}if(window.p56UndoAck&&!window.p56UndoAck.__p84){const old=window.p56UndoAck;const fn=function(key){const r=old.apply(this,arguments);noteOpen(key);return r};fn.__p84=true;window.p56UndoAck=fn}}
function reconcileLocal(){const local=localAsEntries();let next=entries;for(const [k,v] of Object.entries(local)){const cur=next[k];if(!cur||v.changedAt>cur.changedAt)next=mergeEntries(next,{[k]:v})}if(!same(next,entries)){entries=next;writeCloud()}applyEntriesToLocal(entries)}
async function startSync(){if(started||!window.db||!F()||!window.auth?.currentUser)return;started=true;try{const p=await getProfile();if(!p?.memberId){started=false;return}memberRef=F().doc(window.db,'rede_members',p.memberId);const snap=await F().getDoc(memberRef);if(!snap.exists()){started=false;return}const remote=snap.data()?.[CLOUD_FIELD]?.entries||{};entries=mergeEntries(remote,localAsEntries());applyEntriesToLocal(entries);await writeCloud();unsub?.();unsub=F().onSnapshot(memberRef,s=>{if(!s.exists())return;const r=s.data()?.[CLOUD_FIELD]?.entries||{};const merged=mergeEntries(r,entries);entries=merged;applyEntriesToLocal(entries);if(!same(trimEntries(r),entries))setTimeout(writeCloud,100)},e=>console.warn('P84 painel cloud read',e));wrapActions()}catch(e){started=false;console.warn('P84 iniciar sync',e)}}
function waitSync(){if(window.db&&F()&&window.auth?.currentUser)startSync();else setTimeout(waitSync,450)}

async function checkUpdate(){if(!('serviceWorker' in navigator))return;try{const reg=await navigator.serviceWorker.getRegistration('./');if(!reg)return;await reg.update();if(reg.waiting)reg.waiting.postMessage('SKIP_WAITING')}catch(e){console.warn('P84 update check',e)}}
if('serviceWorker' in navigator){let reloading=false;navigator.serviceWorker.addEventListener('controllerchange',()=>{if(reloading)return;reloading=true;const u=new URL(location.href);u.searchParams.set('build',BUILD);u.searchParams.set('apprefresh',Date.now().toString());location.replace(u.href)});window.addEventListener('focus',()=>{checkUpdate();startSync();polish()});document.addEventListener('visibilitychange',()=>{if(!document.hidden){checkUpdate();startSync();polish()}});setTimeout(checkUpdate,1000)}
const obs=new MutationObserver(schedule);obs.observe(document.documentElement,{childList:true,subtree:true});
canonicalize();ensureStyle();polish();waitSync();setInterval(()=>{wrapActions();reconcileLocal();polish()},1600);
window.CARBONAUTAS_RUNTIME_BUILD=BUILD;
console.info('Carbonautas P84 PC/app unificados');
})();
